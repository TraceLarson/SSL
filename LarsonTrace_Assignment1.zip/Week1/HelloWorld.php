<?php
	/*
	 * Trace Larson
	 * 6-29-01
	 * SSL Section 01
	 *  Assignment 1: Run your code
	 *  Question 1
	 */
	
	#1
	class HelloWorld{
		
		public function sayHello(){
			echo "Hello World";
		}
		
	}
	
	$hello = new HelloWorld();
	$hello->sayHello();
	
?>